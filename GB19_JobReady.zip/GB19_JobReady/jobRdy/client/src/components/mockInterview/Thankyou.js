
import React from 'react'

const Thankyou = () => {
  return (
    <div className='display-5 text-white py-2 mb-5'>Session ended</div>
  )
}

export default Thankyou
<?php
require 'admin/dbcon.php';
session_start();

if (isset($_SESSION['voters_id'])) {
	$session_id = $_SESSION['voters_id'];
	$user_query = $conn->query("SELECT * FROM user WHERE user_id = '$session_id'") or die(mysqli_error($conn));

	if ($user_query->num_rows > 0) {
		$user_row = $user_query->fetch_array();
		$user_username = $user_row['firstname'] . " " . $user_row['lastname'];
	} else {
		// Optional: Handle case where user doesn't exist
		$user_username = "Unknown User";
	}
}

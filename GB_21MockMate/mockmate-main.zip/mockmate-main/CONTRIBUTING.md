# Contributing to Full Stack AI Mock Interview App

Thank you for considering contributing to the Full Stack AI Mock Interview App! We appreciate your interest and support. Here are some guidelines to help you get started.

## How to Contribute

1. **Fork the repository**: Click the "Fork" button at the top right corner of the repository page.
2. **Clone your fork**:
   ```bash
   git clone https://github.com/yourusername/full-stack-ai-mock-interview-app.git

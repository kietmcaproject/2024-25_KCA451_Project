/* 
This is the Quick Readme file Simple User Management API
Overview

This is a RESTful API for user management, built using Node.js, Express, MongoDB (Mongoose), and JWT authentication. It supports user signup, login, and CRUD operations with authentication.

Features

User Authentication (JWT-Based)

Signup API (Register new users)

Login API (Generate JWT token on successful login)

Protected User Management APIs (CRUD operations on users)

Role-Based Access Control (Admins can delete users)

Validation using express-validator

Error Handling with Express middleware

Tech Stack

Backend: Node.js, Express.js

Database: MongoDB, Mongoose

Authentication: JWT (JSON Web Tokens)

Validation: Express Validator

Middleware: CORS, Authentication Middleware

Folder Structure

/user-management-api
│── /config
│    ├── db.js               # MongoDB connection setup
│── /controllers
│    ├── authController.js    # Authentication logic
│    ├── userController.js    # User CRUD logic
│── /middlewares
│    ├── authMiddleware.js    # JWT authentication middleware
│── /models
│    ├── User.js              # User model schema
│── /routes
│    ├── authRoutes.js        # Authentication routes
│    ├── userRoutes.js        # User routes (protected)
│── .env                      # Environment variables
│── server.js                 # Entry point
│── package.json              # Dependencies
│── README.md                 # Setup instructions

Installation & Setup




3. Configure Environment Variables

Create a .env file in the root directory and add:


MONGO_URI=mongodb://localhost:27017/Wellfound-Backend
JWT_SECRET=Rishav@321

4. Start the Server

nodemon start  
node server.js


Server will run on http://localhost:5000.

API Endpoints

1. Authentication Routes

Signup

POST /api/auth/signup

{
  "name": "Rishav Kishore",
  "email": "rishav@mail.com",
  "password": "password123"
}

Login

POST /api/auth/login

{
  "email": "rishav@mail.com",
  "password": "password123"
}

Response:

{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjM0NTY3ODkwIiwicm9sZSI6ImFkbWluIiwiaWF0IjoxNjg1MDA5NjAwLCJleHAiOjE3MTY1NjU2MDB9.UtQG9qUqJztvHfC9WvLsPBzzxXvdFxL1mf_5C8vL8mM",
  "user": { "id": "651f3c2a5f4e5b1d2c3a4b5c", "name": "Rishav Kishore", "email": "rishav@mail.com" }
}

2. User Management Routes (Protected)

Create User (Admin Only)

POST /api/users (Requires JWT in Authorization Header)

{
  "name": "K-K Test",
  "email": "kk@mail.com",
  "role": "user"
}

Get All Users

GET /api/users (Requires JWT)

Get Single User

GET /api/users/:id (Requires JWT)

Update User

PUT /api/users/:id (Requires JWT)

{
  "name": "Updated Name"
}

Delete User (Admin Only)

DELETE /api/users/:id (Requires JWT)

*/